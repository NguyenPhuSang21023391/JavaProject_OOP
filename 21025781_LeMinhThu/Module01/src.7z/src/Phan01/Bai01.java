package Phan01;
/**
 * in ra hello world!
 * @author admin
 *
 */
public class Bai01 {

	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
