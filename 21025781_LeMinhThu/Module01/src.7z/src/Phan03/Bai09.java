package Phan03;

/**
 * Viết hàm tách chuỗi gốc thành chuỗi con. 
 */
import java.util.Scanner;

public class Bai09 {
	public static void main(String[] args) {
		String chuoi;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhập vào chuỗi bất kỳ: ");
		chuoi = scanner.nextLine();
		Tachchuoi(chuoi);
	}

	public static void Tachchuoi(String n) {
		char kyTu;
		for (int i = 0; i < n.length(); i++) {
			kyTu = n.charAt(i);
			if (kyTu == ' ') {
				System.out.println();
			} else {
				System.out.print(kyTu);
			}
		}
	}
}
